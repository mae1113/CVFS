package hk.edu.polyu.comp.comp2021.cvfs.model;

import org.junit.Test;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

public class CVFSTest {

    
    @Test
    public void testCVFSConstructor(){
        CVFS cvfs = new CVFS();
        assert true;
    }

    //REQ1 pass
    @Test
    public void test_newDisk() {
        CVFS cvfs = new CVFS();
        // Check initial state (no disks created yet)
        assertEquals(0, cvfs.disks.size());

        cvfs.getcommand("newDisk 1000");

        assertEquals(1, cvfs.disks.size());
        assertNotNull(cvfs.curDisk);

        cvfs.getcommand("newDisk 123");
        assertEquals(2, cvfs.disks.size());
        assertNotNull(cvfs.curDisk);
    }

    //REQ1 pass
    @Test
    public void test_newDisk_error() {
        CVFS cvfs = new CVFS();

        cvfs.getcommand("newDisk one");
        assertEquals(0, cvfs.disks.size());
        assertNull(cvfs.curDisk);

        cvfs.getcommand("newDisk -10");
        assertEquals(0, cvfs.disks.size());
        assertNull(cvfs.curDisk);

        cvfs.getcommand("newDisk  ");
        assertEquals(0, cvfs.disks.size());
        assertNull(cvfs.curDisk);

    }

    //REQ2 pass +REQ4 pass
    @Test
    public void test_newDoc_sameNameTest_deleteDoc() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc yes txt heyiamgood");
        assertTrue(cvfs.workDirectory.exist("yes"));
        assertEquals(1, cvfs.workDirectory.totalcount());
        assertEquals(60, cvfs.curDisk.currentSize);

        cvfs.getcommand("newDoc html html html");
        assertEquals(2, cvfs.workDirectory.totalcount());
        assertEquals(108, cvfs.curDisk.currentSize);

        cvfs.getcommand("newDoc Yes txt heyiamgood");
        assertTrue(cvfs.workDirectory.exist("Yes"));
        assertEquals(3, cvfs.workDirectory.totalcount());
        assertEquals(168, cvfs.curDisk.currentSize);

        cvfs.getcommand("newDoc html css html");    //same name
        assertEquals(3, cvfs.workDirectory.totalcount());
        assertEquals(168, cvfs.curDisk.currentSize);

        //REQ4
        cvfs.getcommand("delete yes");
        assertFalse(cvfs.workDirectory.exist("yes"));
        assertEquals(2, cvfs.workDirectory.totalcount());
        assertEquals(108, cvfs.curDisk.currentSize);
    }

    //REQ2 pass
    @Test
    public void test_newDoc_InvalidName() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newDoc invalid! txt Content"); //only digits & letters
        assertFalse(cvfs.workDirectory.exist("invalid!"));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDoc DocNameTooLong css Name Too Long"); //more than 10
        assertFalse(cvfs.workDirectory.exist("DocNameTooLong"));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDoc  css No name!"); //empty
        assertFalse(cvfs.workDirectory.exist(""));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDoc   "); //empty
        assertFalse(cvfs.workDirectory.exist(""));
        assertEquals(0, cvfs.workDirectory.totalcount());
    }

    //REQ2 pass
    @Test
    public void test_newDoc_InvalidType_noContent() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newDoc test jpg wrong type!"); //invalid doc type
        assertFalse(cvfs.workDirectory.exist("test"));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDoc noType  no."); //no doc type
        assertFalse(cvfs.workDirectory.exist("noType"));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDoc noContent java"); //no doc content
        assertTrue(cvfs.workDirectory.exist("noContent"));
        assertEquals(1, cvfs.workDirectory.totalcount());
        assertEquals(40, cvfs.curDisk.currentSize);
    }

    //REQ2 pass
    @Test
    public void test_newDoc_outOfSize() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 40");

        cvfs.getcommand("newDoc noContent java out of size!!!"); //out of size
        assertFalse(cvfs.workDirectory.exist("doc1"));
        assertEquals(0, cvfs.workDirectory.totalcount());
        assertEquals(0, cvfs.curDisk.currentSize);
    }

    //REQ3 pass
    @Test
    public void test_newDir_sameName() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        assertNotNull(cvfs.workDirectory.getDirectory("hello"));
        assertTrue(cvfs.workDirectory.exist("hello"));
        assertEquals(40, cvfs.curDisk.currentSize);

        cvfs.getcommand("newDir Hello");
        assertTrue(cvfs.workDirectory.exist("Hello"));
        assertEquals(80, cvfs.curDisk.currentSize);

        cvfs.getcommand("newDir Hello");
        assertEquals(80, cvfs.curDisk.currentSize);
    }

    //REQ3 pass
    @Test
    public void test_newDir_InvalidName_empty() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir invalid!"); //only digits & letters
        assertFalse(cvfs.workDirectory.exist("invalid!"));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDir DirNameTooLong"); //more than 10
        assertFalse(cvfs.workDirectory.exist("DirNameTooLong"));
        assertEquals(0, cvfs.workDirectory.totalcount());

        cvfs.getcommand("newDir  "); //empty    //throw exception
        assertFalse(cvfs.workDirectory.exist(""));
        assertEquals(0, cvfs.workDirectory.totalcount());
    }

    //REQ3 pass
    @Test
    public void test_newDir_outOfSize() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 40");

        cvfs.getcommand("newDir Hello");
        assertTrue(cvfs.workDirectory.exist("Hello"));
        assertEquals(40, cvfs.curDisk.currentSize);

        cvfs.getcommand("newDir noContent"); //out of size
        assertFalse(cvfs.workDirectory.exist("noContent"));
        assertEquals(1, cvfs.workDirectory.totalcount());
        assertEquals(40, cvfs.curDisk.currentSize);
    }

    //REQ4 pass
    @Test
    public void test_delete_notFound() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("delete abc");
        assertFalse(cvfs.workDirectory.exist("abc"), "File not found!");

        cvfs.getcommand("delete ");
        assertTrue(!cvfs.workDirectory.exist(" "), "Error: please enter \"delete [fileName]\".");
    }

    //REQ5 pass
    @Test
    public void test_rename() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("rename Yes no");

        assertFalse(cvfs.workDirectory.exist("Yes"));
        assertTrue(cvfs.workDirectory.exist("no"));
    }

    //REQ5 pass
    @Test
    public void test_rename_oldNotFound() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("rename YES no");

        assertFalse(cvfs.workDirectory.exist("no"), "File not found!");

        cvfs.getcommand("rename   ");
        assertTrue(!cvfs.workDirectory.exist(" "), "Error: please enter \"rename [oldFileName] [newFileName]\".");
    }

    //REQ5 pass
    @Test
    public void test_rename_newNameInvalid() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("rename Yes invalid_name");

        assertFalse(cvfs.workDirectory.exist("invalid_name"));
    }

    //REQ6 pass
    @Test
    public void test_changeDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("newDir llo");
        cvfs.getcommand("changeDir hello");
        assertEquals("hello", cvfs.workDirectory.getname());
    }

    //REQ6 pass
    @Test
    public void test_changeDir2() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDir llo");
        cvfs.getcommand("changeDir llo");
        cvfs.getcommand("changeDir ..");
        assertEquals("hello", cvfs.workDirectory.getname());

        cvfs.getcommand("changeDir ..");
        String diskName = cvfs.workDirectory.getname();
        cvfs.getcommand("changeDir ..");
        assertTrue(!cvfs.workDirectory.exist(diskName),"This is already the root directory!");
    }

    //REQ6 pass
    @Test
    public void test_changeDir_invalid() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir llo");
        assertFalse(cvfs.workDirectory.existDir("llo"));

        cvfs.getcommand("changeDir ");
        assertTrue(!cvfs.workDirectory.existDir(" "), "Error: please enter \"changeDir [dirName]\".");
    }

    //REQ7, 8 pass
    @Test
    public void test_list_rList_no_file(){
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("list");
        assertEquals(0,cvfs.workDirectory.totalsize());
        assertFalse(cvfs.workDirectory.exist("Empty"));

        cvfs.getcommand("rList");
        assertEquals(0, cvfs.workDirectory.totalsize());
        assertFalse(cvfs.workDirectory.exist("Empty"));
    }

    //REQ7, 8 pass
    @Test
    public void test_list_valid(){
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("newDoc html css html");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("list");
        assertEquals(3, cvfs.workDirectory.totalcount());
        assertEquals(148,cvfs.workDirectory.totalsize());

        cvfs.getcommand("rList");
        assertEquals(3, cvfs.workDirectory.totalcount());
        assertEquals(148,cvfs.workDirectory.totalsize());
    }

    //REQ9 pass
    @Test
    public void test_newSimpleCri_valid_criAlreadyExists() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        assertTrue(cvfs.isCriExist("bc"));

        cvfs.getcommand("newSimpleCri bb type equals \"css\"");
        assertTrue(cvfs.isCriExist("bb"));

        cvfs.getcommand("newSimpleCri ba size > 46");
        assertTrue(cvfs.isCriExist("ba"));

        cvfs.getcommand("newSimpleCri bc name contains \"same\""); //cri already exists
        assertTrue(cvfs.isCriExist("bc"), "Criteria name already exists!");
    }

    //REQ9 pass
    @Test
    public void test_newSimpleCri_invalid() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri a1 name contains \"doc\"");  //invalid criName
        assertFalse(cvfs.isCriExist("a1"), "Please enter a two English letters criteria name!");

        cvfs.getcommand("newSimpleCri bc name NOTcontains \"doc\""); //invalid "name"
        assertFalse(cvfs.isCriExist("bc"), "If attribute is name, operator can only be \"contains\"");

        cvfs.getcommand("newSimpleCri bc name contains doc"); //invalid "name"
        assertFalse(cvfs.isCriExist("bc"),"If attribute is name, val can only be a string in the double quote!");


        cvfs.getcommand("newSimpleCri bb type equal \"css\""); //invalid "type"
        assertFalse(cvfs.isCriExist("bb"), "If attribute is type, operator can only be \"equals\"");

        cvfs.getcommand("newSimpleCri bb type equals css"); //invalid "type"
        assertFalse(cvfs.isCriExist("bb"),"If attribute is type, val can only be a string in the double quote!");

        cvfs.getcommand("newSimpleCri aa type equals \"jpg\""); //invalid "type"
        assertFalse(cvfs.isCriExist("aa"),"If attribute is type, val can only be html, css, java, or txt!");

        cvfs.getcommand("newSimpleCri ba size = 46");   //invalid size
        assertFalse(cvfs.isCriExist("ba"), "If attribute is size, operator can only be >, <, >=, <=, ==, or !=");

        cvfs.getcommand("newSimpleCri ba size == 4.6");   //invalid size
        assertFalse(cvfs.isCriExist("ba"),"If attribute is size, val must be integer");

        cvfs.getcommand("newSimpleCri cc idk contains \"same\"");
        assertFalse(cvfs.isCriExist("cc"),"Attribute name can only be \"name\", \"type\", and \"size\"");

        cvfs.getcommand("newSimpleCri ");
        assertTrue(!cvfs.isCriExist(""), "Error: please enter \"newSimpleCri [criName] [attrName] [op] [val]\".");
    }

    //REQ11 pass
    @Test
    public void test_newNegation_alreadyexists() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        cvfs.getcommand("newSimpleCri bb type equals \"css\"");
        cvfs.getcommand("newSimpleCri ba size > 46");

        cvfs.getcommand("newNegation cb bc");
        assertTrue(cvfs.isCriExist("cb"));
        cvfs.getcommand("newNegation cb bb");
        assertTrue(cvfs.isCriExist("cb"), "Criteria name already exists!");
    }

    //REQ11 pass
    @Test
    public void test_newNegation_criNotFound() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newNegation cb bc");
        assertFalse(cvfs.isCriExist("bc"), "Criteria not found!");

        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        cvfs.getcommand("newNegation acb bc");
        assertFalse(cvfs.isCriExist("acb"), "Please enter a two English letters for criteria name!");

        cvfs.getcommand("newNegation ");
        assertFalse(cvfs.isCriExist(" "));
    }

    //REQ11 pass
    @Test
    public void test_newBinaryCri_alreadyexists() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri bb type equals \"css\"");
        cvfs.getcommand("newBinaryCri bd bb && IsDocument");
        assertTrue(cvfs.isCriExist("bd"));

        cvfs.getcommand("newSimpleCri ab name contains \"abc\"");
        cvfs.getcommand("newSimpleCri ac type equals \"java\"");
        cvfs.getcommand("newNegation ae ab");
        cvfs.getcommand("newBinaryCri af ae || ac");
        assertTrue(cvfs.isCriExist("af"));

        cvfs.getcommand("newBinaryCri af ae && bd");
        assertTrue(cvfs.isCriExist("af"), "Criteria name already exists!");
    }

    //REQ11 pass
    @Test
    public void test_newBinaryCri_invalid() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newBinaryCri bd bb && IsDocument");
        assertFalse(cvfs.isCriExist("bd"), "Criteria not found!");

        cvfs.getcommand("newSimpleCri ab name contains \"abc\"");
        cvfs.getcommand("newSimpleCri ac type equals \"java\"");
        cvfs.getcommand("newNegation ae ab");
        cvfs.getcommand("newBinaryCri ace ae || ac");
        assertFalse(cvfs.isCriExist("ace"), "Please enter a two English letters for criteria name!");

        cvfs.getcommand("newBinaryCri af ae & ac");
        assertFalse(cvfs.isCriExist("af"), "Logic operator can only be && or || !");

        cvfs.getcommand("newBinaryCri af ae || ae");
        assertFalse(cvfs.isCriExist("af"), "The two selected criteria can not be the same");

        cvfs.getcommand("newBinaryCri   ");
        assertFalse(cvfs.isCriExist(""));
    }

    //REQ12 pass
    @Test
    public void test_printAllCriteria() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newSimpleCri bb type equals \"css\"");
        cvfs.getcommand("newBinaryCri bd bb && IsDocument");

        cvfs.getcommand("newSimpleCri ab name contains \"abc\"");
        cvfs.getcommand("newSimpleCri ac type equals \"java\"");
        cvfs.getcommand("newNegation ae ab");
        cvfs.getcommand("newBinaryCri af ae || ac");

        cvfs.getcommand("printAllCriteria");
        assertTrue(cvfs.isCriExist("bb"));
        assertTrue(cvfs.isCriExist("bd"));
        assertTrue(cvfs.isCriExist("ab"));
        assertTrue(cvfs.isCriExist("ac"));
        assertTrue(cvfs.isCriExist("ae"));
        assertTrue(cvfs.isCriExist("af"));

    }

    //REQ13
    @Test
    public void test_searchType() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri bb type equals \"txt\"");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search bb");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch bb");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchName() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri bb name contains \"yes\"");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search bb");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch bb");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchSizeLarger() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri ba size > 40");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search ba");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch ba");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchSizeSmaller() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri ba size < 100");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search ba");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch ba");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchSizeLargerEqual() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri ba size >= 40");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search ba");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch ba");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchSizeSmallerEqual() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri ba size <= 100");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search ba");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch ba");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchSizeEqual() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri ba size == 46");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search ba");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch ba");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    @Test
    public void test_searchSizeNOTEqual() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDoc yes txt hii");
        cvfs.getcommand("newSimpleCri ba size != 100");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("search ba");
        System.setOut(originalOut);

        String output = outputStream.toString().trim();

        String expectedOutput = "Current directory: hello\n\n" +
                "Document: \n" +
                "\tName: yes, Type: txt, Size: 46 bytes\n" +
                "Directory: \n" +
                "\tEmpty\n" +
                "Total number: 1, Total size: 46";

        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        cvfs.getcommand("rSearch ba");
        assertEquals(normalizedExpected, normalizedOutput);
    }

    //REQ14 pass
    @Test
    public void test_rSearch() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir 1");
        cvfs.getcommand("changeDir 1");
        cvfs.getcommand("newDoc thisd css this is doc.");
        cvfs.getcommand("newDir 10");
        cvfs.getcommand("changeDir 10");
        cvfs.getcommand("newDoc b txt this is doc.");
        cvfs.getcommand("newDir 100");
        cvfs.getcommand("changeDir 100");
        cvfs.getcommand("newDir 1000");
        cvfs.getcommand("changeDir ..");
        cvfs.getcommand("changeDir ..");
        cvfs.getcommand("newSimpleCri aa size > 45");
        cvfs.getcommand("newBinaryCri ab aa && IsDocument");
        cvfs.getcommand("newNegation ac IsDocument");

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("rSearch aa");
        System.setOut(originalOut);
        String output = outputStream.toString().trim();
        String expectedOutput = "Name: 1, Size: 140\n" +
                "\tDocument: \n" +
                "\t\tName: thisd, Type: css, Size: 60 bytes\n" +
                "\tDirectory:\n" +
                "\t\tName: 10, Size: 140\n" +
                "\t\t\tDocument: \n" +
                "\t\t\t\tName: b, Type: txt, Size: 60 bytes\n" +
                "\t\t\tDirectory:\n" +
                "\t\t\t\tName: 100, Size: 80 bytes\n" +
                "Total number: 4, total size: 200";
        String normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        String normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        outputStream = new ByteArrayOutputStream();
        originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("rSearch ab");
        System.setOut(originalOut);
        output = outputStream.toString().trim();
        expectedOutput = "Name: 1, Size: 140\n" +
                "\tDocument: \n" +
                "\t\tName: thisd, Type: css, Size: 60 bytes\n" +
                "\tDirectory:\n" +
                "\t\tName: 10, Size: 140\n" +
                "\t\t\tDocument: \n" +
                "\t\t\t\tName: b, Type: txt, Size: 60 bytes\n" +
                "\t\t\tDirectory:\n" +
                "\t\t\t\tEmpty\n" +
                "Total number: 3, total size: 200";
        normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);

        outputStream = new ByteArrayOutputStream();
        originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
        cvfs.getcommand("rSearch ac");
        System.setOut(originalOut);
        output = outputStream.toString().trim();
        expectedOutput = "Name: 1, Size: 140\n" +
                "\tDocument: \n" +
                "\t\tEmpty\n" +
                "\tDirectory:\n" +
                "\t\tName: 10, Size: 140\n" +
                "\t\t\tDocument: \n" +
                "\t\t\t\tEmpty\n" +
                "\t\t\tDirectory:\n" +
                "\t\t\t\tName: 100, Size: 80\n" +
                "\t\t\t\t\tDocument: \n" +
                "\t\t\t\t\t\tEmpty\n" +
                "\t\t\t\t\tDirectory:\n" +
                "\t\t\t\t\t\tName: 1000, Size: 40 bytes\n" +
                "Total number: 3, total size: 140";
        normalizedOutput = output.replace("\r\n", "\n").replace("\r", "\n");
        normalizedExpected = expectedOutput.replace("\r\n", "\n").replace("\r", "\n");

        assertEquals(normalizedExpected, normalizedOutput);
    }

    //REQ13, 14 pass
    @Test
    public void test_search_rSearch_notFound() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newSimpleCri bb type equals \"css\"");

        cvfs.getcommand("search bac");
        assertFalse(cvfs.isCriExist("bac"), "Criteria not found!");

        cvfs.getcommand("rSearch bc");
        assertFalse(cvfs.isCriExist("bc"), "Criteria not found!");

        cvfs.getcommand("search  ");
        assertFalse(cvfs.isCriExist(" "), "Criteria not found!");

        cvfs.getcommand("rSearch  ");
        assertFalse(cvfs.isCriExist(" "), "Criteria not found!");
    }

    //REQ15, BON1 pass
    @Test
    public void test_save() {
        CVFS cvfs = new CVFS();
        Path path = Paths.get("testpurpose");
        try{
        Files.deleteIfExists(path.resolve("Yes.txt"));
        Files.deleteIfExists(path.resolve("Criteria_List.txt"));
        path = path.resolve("10");
        Files.deleteIfExists(path.resolve("100"));
        Files.deleteIfExists(path.resolve("hi.java"));
        path = Paths.get("testpurpose");
        Files.deleteIfExists(path.resolve("10"));}catch(IOException e){}
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt iamreal");
        cvfs.getcommand("newDir 10");
        cvfs.getcommand("changeDir 10");
        cvfs.getcommand("newDoc hi java notreal");
        cvfs.getcommand("newDir 100");
        cvfs.getcommand("changeDir ..");
        cvfs.getcommand("newSimpleCri aa type equals \"txt\"");
        cvfs.getcommand("newNegation ab IsDocument");
        cvfs.getcommand("save testpurpose");
        assertTrue(Files.exists(path.resolve("10")));
        assertTrue(Files.exists(path.resolve("Yes.txt")));
        assertTrue(Files.exists(path.resolve("Criteria_List.txt")));
        path = path.resolve("10");
        assertTrue(Files.exists(path.resolve("100")));
        assertTrue(Files.exists(path.resolve("hi.java")));
    }

    //REQ15 pass
    @Test
    public void test_save_invalid() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("save ");
    }

    //REQ16, BON1 pass
    @Test
    public void test_load() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("load testpurpose");
        assertFalse(cvfs.workDirectory.exist("Criteria_List"));
        assertTrue(cvfs.workDirectory.exist("Yes"));
        cvfs.getcommand("changeDir 10");
        assertTrue(cvfs.workDirectory.exist("100"));
        assertTrue(cvfs.workDirectory.exist("hi"));
        assertTrue(cvfs.isCriExist("aa"));
        assertTrue(cvfs.isCriExist("ab"));
    }

    //REQ16 pass
    @Test
    public void test_load_invalid() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("load ");
    }

    //BON2
    //undo
    @Test
    public void test_undo_newDoc() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("undo");

        assertFalse(cvfs.workDirectory.exist("Yes"));
    }

    @Test
    public void test_undo_newDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir 10");
        cvfs.getcommand("undo");

        assertFalse(cvfs.workDirectory.exist("10"));
    }

    @Test
    public void test_undo_newDisk_cannotUndo() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("undo");
        // new disk cannot be undone
        assertEquals(1, cvfs.disks.size());
        assertNotNull(cvfs.curDisk);
    }

    @Test
    public void test_undo_delete() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt iamreal");
        cvfs.getcommand("delete Yes");
        cvfs.getcommand("undo");

        assertTrue(cvfs.workDirectory.exist("Yes"));
    }

    @Test
    public void test_undo_renamedoc() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt iamreal");
        cvfs.getcommand("rename Yes no");
        cvfs.getcommand("undo");

        assertTrue(cvfs.workDirectory.exist("Yes"));
        assertFalse(cvfs.workDirectory.exist("no"));
    }

    @Test
    public void test_undo_renameDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("rename hello byebye");
        cvfs.getcommand("undo");

        assertTrue(cvfs.workDirectory.exist("hello"));
        assertFalse(cvfs.workDirectory.exist("byebye"));
    }

    @Test
    public void test_undo_changeDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDir llo");
        cvfs.getcommand("changeDir llo");
        cvfs.getcommand("undo");

        assertEquals("hello", cvfs.workDirectory.getname());
    }

    @Test
    public void test_undo_changeDirRoot() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("changeDir ..");
        cvfs.getcommand("undo");
        assertEquals("hello", cvfs.workDirectory.getname());
    }

    @Test
    public void test_undo_newSimpleCri() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        cvfs.getcommand("undo");
        assertFalse(cvfs.isCriExist("bc"));
    }

    @Test
    public void test_undo_newNegation() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        cvfs.getcommand("newNegation cb bc");
        cvfs.getcommand("undo");
        assertTrue(cvfs.isCriExist("bc"));
        assertFalse(cvfs.isCriExist("cb"));
    }

    //redo (done after undo)
    @Test
    public void test_redo_withoutUndo() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("redo");

        assertTrue(cvfs.undohis.isEmpty(), "Can not redo without undo");
    }

    @Test
    public void test_redo_newDoc() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt heyiamgood");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");

        assertTrue(cvfs.workDirectory.exist("Yes"));
    }

    @Test
    public void test_redo_newDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir 10");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");

        assertTrue(cvfs.workDirectory.exist("10"));
    }

    @Test
    public void test_redo_delete() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt iamreal");
        cvfs.getcommand("delete Yes");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");

        assertFalse(cvfs.workDirectory.exist("Yes"));
    }

    @Test
    public void test_redo_renamedoc() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDoc Yes txt iamreal");
        cvfs.getcommand("rename Yes no");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");

        assertTrue(cvfs.workDirectory.exist("no"));
        assertFalse(cvfs.workDirectory.exist("Yes"));
    }

    @Test
    public void test_redo_renameDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("rename hello byebye");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");

        assertTrue(cvfs.workDirectory.exist("byebye"));
        assertFalse(cvfs.workDirectory.exist("hello"));
    }

    @Test
    public void test_redo_changeDir() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");
        cvfs.getcommand("newDir hello");
        cvfs.getcommand("changeDir hello");
        cvfs.getcommand("newDir llo");
        cvfs.getcommand("changeDir llo");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");

        assertEquals("llo", cvfs.workDirectory.getname());
    }

    @Test
    public void test_redo_newSimpleCri() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");
        assertTrue(cvfs.isCriExist("bc"));
    }

    @Test
    public void test_redo_newNegation() {
        CVFS cvfs = new CVFS();
        cvfs.getcommand("newDisk 1000");

        cvfs.getcommand("newSimpleCri bc name contains \"doc\"");
        cvfs.getcommand("newNegation cb bc");
        cvfs.getcommand("undo");
        cvfs.getcommand("redo");
        assertTrue(cvfs.isCriExist("cb"));
    }
}





