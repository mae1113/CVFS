package hk.edu.polyu.comp.comp2021.cvfs;

import java.util.Scanner;

import hk.edu.polyu.comp.comp2021.cvfs.model.CVFS;

public class Application {

    public static void main(String[] args){
        CVFS cvfs = new CVFS();
        // Initialize and utilize the system

        String command="";
        do{
            System.out.println("Enter a command ");
            Scanner objScanner = new Scanner(System.in);
        
            command = objScanner.nextLine().trim();
            //System.out.println(command);
            cvfs.getcommand(command);

        }while(!command.equalsIgnoreCase("quit"));
    }
}
