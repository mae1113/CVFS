package hk.edu.polyu.comp.comp2021.cvfs.model;

public class Disk {
    static int count;
    public String name;
    public Directory dir;
    public int size;
    public int currentSize;


    public Disk(int size){
        count++;
        this.size = size;
        this.name = "Disk "+count;
        this.currentSize = 0;
        this.dir = new Directory(this.name);
    }
    
    
    public boolean outofsize(int size){
        if (this.currentSize+size>this.size){
            System.out.println("The disk is out of space to add this file.");
            return true;
        }
        return false;
    }
    public void increaseSize(int size){
        this.currentSize +=size;
    }
    public void decraseSize(int size){
        this.currentSize -=size;
    }

    public String getname(){
        return this.name;
    }

    public Directory getDirectory(){
        return this.dir;
    }

    public int getcurrentsize(){
        return this.currentSize;
    }

    public int getmaxsize(){
        return this.size;
    }
    
}
