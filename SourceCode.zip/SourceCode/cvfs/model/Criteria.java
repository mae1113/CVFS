package hk.edu.polyu.comp.comp2021.cvfs.model;

public class Criteria {
    Document doc;
    String criName;
    String attrName;
    String op;
    String val;
    boolean isDoc;
    String logicOp;

    public Criteria(){

    }
}
