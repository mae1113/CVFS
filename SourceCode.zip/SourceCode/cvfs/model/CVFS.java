package hk.edu.polyu.comp.comp2021.cvfs.model;

import java.util.ArrayList;

public class CVFS {
    String root;
    ArrayList<String> dirlis = new ArrayList<String>();
    ArrayList<Disk> disks = new ArrayList<Disk>();
    Directory workDirectory;
    Disk curDisk;
    String getcommand;

    public boolean wrongName(String name){
        if (name.isEmpty()||name.length()>10){
            System.out.println("File name may have at most 10 characters and not empty");
            return true;
        }
        if (!name.matches("[a-zA-Z0-9]+")){
            System.out.println("Only digits and English letters are allowed in file names");
            return true;
        }
        return false;
    }

    public void createDisk(int size){
        Disk d = new Disk(size);
        this.disks.add(d);
        this.root = d.getname();
        
        this.dirlis.clear();
        this.dirlis.add(root);
        this.workDirectory = this.disks.get(this.disks.size()-1).getDirectory();
        this.curDisk = this.disks.get(this.disks.size()-1);
    }

    public Disk getDisk(String name){
        for(Disk i: disks){
            if (i.getname() == name){
                return i;
            }
        }
        System.out.println("Disk not found.");
        return null;
    }

    public CVFS(){
        
    }

    public void getcommand(String command){
        String[] com = command.split(" ");
        String realcom = com[0];

        /* 
        if (com.length>5){System.out.println("Please enter the command correctly");
        return;
        }
        */

        //REQ 1
        if(realcom.equals("newDisk")){
            this.createDisk(Integer.valueOf(com[1]));
            System.out.println("Disk created!");
            //System.out.println(this.workDirectory.name);
        }

        //REQ 2
        if(realcom.equals("newDoc")){
            if(wrongName(com[1])){
                return;
            }
            String resString="";
            for (int i =3;i<com.length;i++){
                resString+=com[i];
            }

            Document doc = new Document(com[1], com[2], resString);
            Disk curdisk = this.curDisk;
            if(curdisk.outofsize(Integer.valueOf(doc.getsize())))return;

            this.workDirectory.createDocument(doc);

            if(this.workDirectory.executedfully()){
                curdisk.increaseSize(doc.getsize());

                System.out.println("Document created!");
                this.workDirectory.list();
            }
        }

        //REQ 3
        if(realcom.equals("newDir")){
            if(wrongName(com[1]))return;
            
            Directory d = new Directory(com[1]);
            Disk curdisk = this.curDisk;
            if(curdisk.outofsize(Integer.valueOf(d.getsize())))return;

            this.workDirectory.createDirectory(d);
            if(this.workDirectory.executedfully()){
                curdisk.increaseSize(d.getsize());

                System.out.println("Directory created!");
                this.workDirectory.list();
            }
        }

        //REQ 4
        if (realcom.equals("delete")){
            if (!this.workDirectory.exist(com[1])){
                System.out.println("File not found!");
                return;
            }

            int minus = this.workDirectory.deleteFile(com[1]);
            if(this.workDirectory.executedfully()){
                System.out.println("File deleted!");
                Disk curdisk = this.curDisk;
                curdisk.decraseSize(minus);
                this.workDirectory.list();
            }
        }

        //REQ5
        if(realcom.equals("rename")){
            if(wrongName(com[2]))return;
            if (!this.workDirectory.exist(com[1])){
                System.out.println("File not found!");
                return;
            }

            if(this.workDirectory.rename(com[1], com[2])){
                System.out.println("File renamed!");
                this.workDirectory.list();
            }
        }

        //REQ6
        if(realcom.equals("changeDir")){
            System.out.println(this.dirlis.get(0));
            if (!com[1].equals("..")&&!this.workDirectory.existDir(com[1])){
                System.out.println("Directory not found!");
                return;
            }
            if (com[1].equals("..")){
                if(this.workDirectory.getname().equals(this.dirlis.get(0))){
                    System.out.println("This is already the root directory!");
                    return;
                }
                this.dirlis.remove(this.dirlis.size()-1);
                this.workDirectory = this.curDisk.getDirectory();
                for (int i=0; i< this.dirlis.size()-1; i++){
                    this.workDirectory = this.workDirectory.getDirectory(this.dirlis.get(i));
                }
                System.out.println("Working directory changed!");
                this.workDirectory.list();
            }

            else{
                this.workDirectory = this.workDirectory.getDirectory(com[1]);
                this.dirlis.add(com[1]);
                System.out.println("Working directory changed!");
                this.workDirectory.list();
            }   
        }

        //REQ 7
        if (realcom.equals("list")){
            this.workDirectory.list();
        }

        //REQ 8 not done , -, https://www.geeksforgeeks.org/java-string-class-indent-method-with-examples/
        /**/ 
        if (realcom.equals("rlist")){
            System.out.println(this.workDirectory.rlist(0));
            System.out.println("Total number: "+this.workDirectory.totalcount()+", total size: "+this.workDirectory.totalsize()+"\n");
        }

        //REQ 9 
        if (realcom.equals("newSimpleCri")){

        }

    } 
}
