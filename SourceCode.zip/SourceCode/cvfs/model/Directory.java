package hk.edu.polyu.comp.comp2021.cvfs.model;
import java.util.ArrayList;

public class Directory {
    public String name;
    public ArrayList<Document> documents = new ArrayList<Document>();
    public ArrayList<Directory> subDirs = new ArrayList<Directory>();
    public int size;
    public int count;
    private boolean executedfully = false;

    public Directory (String name){
        this.name = name;
        this.size = 40 + documents.size() + subDirs.size();
        this.count = this.documents.size()+this.documents.size();
    }

    public Directory getDirectory(String name){
        Directory res;
        for (Directory i : this.subDirs){
            if (i.name.equals(name)){
                res = i;
                return res;
            }
        }
        return null;
    }

    public boolean executedfully(){
        return this.executedfully;
    }
    public String getname(){
        return this.name;
    }
    public int getsize(){
        return this.size;
    }
    public int getcount(){
        return this.count;
    }

    public boolean rename(String old, String n){
        for (Directory i : this.subDirs){
            if (i.getname().equals(old)){i.name = n;return true;}
        }
        for (Document i : this.documents){
            if (i.getname().equals(old)){i.rename(n);return true;}
        }
        return false;
    }

    public boolean exist(String name){
        for (Directory i : this.subDirs){
            if (i.getname().equals(name))return true;
        }
        for (Document i : this.documents){
            if (i.getname().equals(name))return true;
        }

        return false;
    }

    public boolean existDir(String name){
        for (Directory i : this.subDirs){
            if (i.getname().equals(name))return true;
        }
        return false;
    }


    public boolean isdoc(String name){
        for (Document i : this.documents){
            if (i.getname().equals(name))return true;
        }
        return false;
    }

    public void changeFileName(String old, String name){
        if(this.exist(name)){
            System.out.println("There is another file with the same name, please choose another name for this file");
            return;
        }
        if(!this.exist(old)){
            System.out.println("This file is not found");
            return;
        }
        for (Directory i : this.subDirs){
            if (i.name.equals(old))i.name = name;return;
        }
        for (Document i : this.documents){
            if (i.name.equals(old))i.rename(name);return;
        }
    }

    public void createDocument(Document a){
        executedfully = false;

        if(this.exist(a.name)){
            System.out.println("There is another file with the same name, please choose another name for this file");
            return;
        }
        if (!a.type.matches("txt|java|html|css")){
            System.out.println("Only types txt, java, html, and css are allowed");
            return;
        }
        
        this.size+=a.size;
        this.count++;
        this.documents.add(a);
        executedfully = true;
    }

    public void createDirectory(Directory a){
        this.executedfully = false;
        if(this.exist(a.getname())){
            System.out.println("There is another file with the same name, please choose another name for this file");
            return;
        }

        this.size+=a.size;
        this.count++;
        this.subDirs.add(a);
        this.executedfully = true;
    }
    
    public int deleteFile(String a){
        this.executedfully = false;
        int res =0;
        for (Document i : this.documents){
            if (i.getname().equals(a)){
                res = i.getsize();
                this.count--;
                this.size-=res;
                this.executedfully = this.documents.remove(i);
            }
        }
        for (Directory i : this.subDirs){
            if (i.getname().equals(a)){
                res = i.getsize();
                this.count--;
                this.size-=res;
                this.executedfully = this.subDirs.remove(i);
            }
        }
        return res;
    }

    public String lis(){
        String r ="\tName: "+this.name+", Size: "+this.size+" bytes";
        return r;
    }

    public void list(){
        int count = 0, size = 0;
        System.out.println("\nCurrent directory: "+this.name+"\n\nDocument: ");
        for (Document i : this.documents){
            System.out.println(i.lis());
            count++;
            size+=i.size;
        }
        if (this.documents.isEmpty())System.out.println("\tEmpty");

        System.out.println("Directory: ");
        for (Directory i : this.subDirs){
            System.out.println(i.lis());
            count++;
            size+=i.size;
        }
        if (this.subDirs.isEmpty())System.out.println("\tEmpty");

        System.out.println("Total number: "+count+", Total size: "+size+"\n");
    }


    public String ident(int level){
        String r="\n";
        for(int i =0;i<level;i++){
            r+= "\t";
        }
        return r;
    }

    public int totalcount(){
        int r=0;
        if(!this.subDirs.isEmpty()){
            for (Directory i : this.subDirs){
                r+=i.totalcount()+1;
            }
        }
        r+=this.documents.size();
        return r;
    }
    public int totalsize(){
        int r=0;
        if(!this.subDirs.isEmpty()){
            for (Directory i : this.subDirs){
                r+=i.totalsize()+40;
            }
        }
        for (Document i : this.documents){
            r+=i.getsize();
        }
        return r;
    }

    public String rlist(int level){
        String res=ident(level)+"Directory: "+this.getname() +" size:"+this.getsize();
        if (this.getname().contains("Disk")){
            res=ident(level)+"Directory: "+this.getname();
        }
        level++;
        //base case
        if (this.subDirs.isEmpty()){
            res+=ident(level)+"Document: ";
            for (Document i : this.documents){
                res+=ident(level)+i.lis();
            }
            if (this.documents.isEmpty())res+=ident(level)+"\tEmpty";
            res+=ident(level)+"Directory:"+ident(level)+"\tEmpty";
            return res;
        }
        //

        res+=ident(level)+"Document: ";
        for (Document i : this.documents){
            res+=ident(level)+i.lis();
        }
        if (this.documents.isEmpty())res+=ident(level)+"\tEmpty";
        res+=ident(level)+"Directory:";
        for (Directory i : this.subDirs){
            res+=i.rlist(level+1);
        }
        return res;

    }

}
