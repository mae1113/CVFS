package hk.edu.polyu.comp.comp2021.cvfs.model;

public class Document {
    public String name;
    public String type;
    public String content;
    public int size;

    public Document (String name, String type, String content){
        /*if (name.isEmpty()||name.length()>10){
            System.out.println("File name may have at most 10 characters and not empty");
            return;
        }
        if (!name.matches("a-zA-Z0-9]+")){
            System.out.println("Only digits and English letters are allowed in file names");
            return;
        }*/
        this.name = name;

        
        this.type = type;
        this.content = content;
        size = 40 + content.length()*2;
    }

    public void rename(String name){
        this.name = name;
    }
    public int getsize(){
        return this.size;
    }
    public String getname(){
        return this.name;
    }
    public String gettype(){
        return this.type;
    }

    public String lis(){
        String r = "\tName: "+this.name+", Type: "+this.type+", Size: "+this.size+" bytes";
        return r;
    }
}
