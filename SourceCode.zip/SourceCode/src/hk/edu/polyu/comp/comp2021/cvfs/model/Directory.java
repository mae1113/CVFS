package hk.edu.polyu.comp.comp2021.cvfs.model;
import java.nio.file.DirectoryStream;
import java.util.ArrayList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class Directory {
    public String name;
    public ArrayList<Document> documents = new ArrayList<Document>();
    public ArrayList<Directory> subDirs = new ArrayList<Directory>();
    public int size;
    public int count;
    private boolean executedfully = false;

    public Directory (String name){
        this.name = name;
        this.size = 40 + documents.size() + subDirs.size();
        this.count = this.documents.size() + this.documents.size();
    }

    public Directory getDirectory(String name){
        Directory res;
        for (Directory i : this.subDirs){
            if (i.name.equals(name)){
                res = i;
                return res;
            }
        }
        return null;
    }

    public boolean executedfully(){
        return this.executedfully;
    }
    public String getname(){
        return this.name;
    }
    public int getsize(){return this.size; }

    public boolean rename(String old, String n){
        for (Directory i : this.subDirs){
            if (i.getname().equals(old)){i.name = n;return true;}
        }
        for (Document i : this.documents){
            if (i.getname().equals(old)){i.rename(n);return true;}
        }
        return false;
    }

    public boolean exist(String name){
        for (Directory i : this.subDirs){
            if (i.getname().equals(name))return true;
        }
        for (Document i : this.documents){
            if (i.getname().equals(name))return true;
        }

        return false;
    }

    public boolean existDir(String name) {
        for (Directory i : this.subDirs) {
            if (i.getname().equals(name)) return true;
        }
        return false;
    }

    public void createDocument(Document a){
        executedfully = false;

        if(this.exist(a.name)){
            System.out.println("There is another file with the same name, please choose another name for this file");
            return;
        }
        if (!a.type.matches("txt|java|html|css")){
            System.out.println("Only types txt, java, html, and css are allowed");
            return;
        }

        this.size+=a.size;
        this.count++;
        this.documents.add(a);
        executedfully = true;
    }

    public void createDirectory(Directory a){
        this.executedfully = false;
        if(this.exist(a.getname())){
            System.out.println("There is another file with the same name, please choose another name for this file");
            return;
        }

        this.size+=a.size;
        this.count++;
        this.subDirs.add(a);
        this.executedfully = true;
    }

    public int deleteFile(String a){
        this.executedfully = false;
        int res = 0;
        for (Document i : this.documents){
            if (i.getname().equals(a)){
                res = i.getsize();
                this.count--;
                this.size-=res;
                this.executedfully = this.documents.remove(i);
                return res;

            }
        }
        for (Directory i : this.subDirs){
            if (i.getname().equals(a)){
                res = i.getsize();
                this.count--;
                this.size-=res;
                this.executedfully = this.subDirs.remove(i);
                return res;

            }
        }
        return res;

    }

    public String lis(){
        String r ="\tName: "+this.name+", Size: "+this.size+" bytes";
        return r;
    }

    public void list(){
        int count = 0, size = 0;
        System.out.println("\nCurrent directory: "+this.name+"\n\nDocument: ");
        for (Document i : this.documents){
            System.out.println(i.lis());
            count++;
            size+=i.size;
        }
        if (this.documents.isEmpty())System.out.println("\tEmpty");

        System.out.println("Directory: ");
        for (Directory i : this.subDirs){
            System.out.println(i.lis());
            count++;
            size+=i.size;
        }
        if (this.subDirs.isEmpty())System.out.println("\tEmpty");

        System.out.println("Total number: "+count+", Total size: "+size+"\n");
    }


    public String ident(int level){
        String r="\n";
        for(int i =0;i<level;i++){
            r+= "\t";
        }
        return r;
    }

    public int totalcount(){
        int r=0;
        if(!this.subDirs.isEmpty()){
            for (Directory i : this.subDirs){
                r+=i.totalcount()+1;
            }
        }
        r+=this.documents.size();
        return r;
    }
    public int totalsize(){
        int r=0;
        if(!this.subDirs.isEmpty()){
            for (Directory i : this.subDirs){
                r+=i.totalsize()+40;
            }
        }
        for (Document i : this.documents){
            r+=i.getsize();
        }
        return r;
    }

    public String rList(int level){
        String res=ident(level)+"Directory: "+this.getname() +", size: "+this.getsize();
        if (this.getname().contains("Disk")){
            res=ident(level)+"Directory: "+this.getname();
        }
        level++;
        //base case
        if (this.subDirs.isEmpty()){
            res+=ident(level)+"Document: ";
            for (Document i : this.documents){
                res += ident(level)+i.lis();
            }
            if (this.documents.isEmpty())res+=ident(level)+"\tEmpty";
            res+=ident(level)+"Directory:"+ident(level)+"\tEmpty";
            return res;
        }


        res+=ident(level)+"Document: ";
        for (Document i : this.documents){
            res+=ident(level)+i.lis();
        }
        if (this.documents.isEmpty())res+=ident(level)+"\tEmpty";
        res+=ident(level)+"Directory:";
        for (Directory i : this.subDirs){
            res+=i.rList(level+1);
        }
        return res;

    }

    public Directory CriList(Criteria cri, ArrayList<Criteria> crilist){
        Directory tempDirectory = new Directory(this.getname());

        for (Document i : this.documents){
            files file = new files();
            file.setDoc(i);
            if(cri.search(file, crilist))tempDirectory.createDocument(i);
        }
        for (Directory i : this.subDirs){
            files file = new files();
            file.setDir(i);
            if(cri.search(file, crilist))tempDirectory.createDirectory(i);
        }

        return tempDirectory;
    }

    public boolean checkCrilist(Criteria cri, ArrayList<Criteria> crilist){
        for (Document i : this.documents){
            files file = new files();
            file.setDoc(i);
            if(cri.search(file, crilist))return true;
        }
        for (Directory i : this.subDirs){
            if(i.checkCrilist(cri, crilist))return true;
            files file = new files();
            file.setDir(i);
            if(cri.search(file, crilist))return true;
        }
        return false;
    }

    public int rcricount(Criteria cri, ArrayList<Criteria> crilist, int cricount){
        // base case
        if (this.subDirs.isEmpty()){
            for (Document i : this.documents){
                files file = new files();
                file.setDoc(i);
                if(cri.search(file, crilist)){
                    cricount++;
                }
            }return cricount;
        }
        //
        for (Document i : this.documents){
            files file = new files();
            file.setDoc(i);
            if(cri.search(file, crilist)){
                cricount++;
            }
        }
        for (Directory i : this.subDirs){
            if (i.checkCrilist(cri, crilist)){
                cricount += i.rcricount(cri, crilist, 0);
                cricount++;
            }
            else {
                files file = new files();
                file.setDir(i);
                if(cri.search(file, crilist)){
                    cricount++;
                }
            }
        }
        return cricount;
    }

    public int rcrisize(Criteria cri, ArrayList<Criteria> crilist, int crisize){
        // base case
        if (this.subDirs.isEmpty()){
            for (Document i : this.documents){
                files file = new files();
                file.setDoc(i);
                if(cri.search(file, crilist)){
                    crisize += i.getsize();
                }
            }return crisize;
        }

        for (Document i : this.documents){
            files file = new files();
            file.setDoc(i);
            if(cri.search(file, crilist)){
                crisize += i.getsize();
            }
        }
        for (Directory i : this.subDirs){
            if (i.checkCrilist(cri, crilist)){
                crisize += i.getsize();
            }
            else {
                files file = new files();
                file.setDir(i);
                if(cri.search(file, crilist)){
                    crisize += i.getsize();
                }
            }
        }
        return crisize;
    }

    public String rCri (Criteria cri, ArrayList<Criteria> crilist, int level){
        String res=ident(level)+"Name: "+this.getname() +", Size: "+this.getsize();
        if (this.getname().contains("Disk")){
            res=ident(level)+"Directory: "+this.getname();
        }
        boolean check;
        level++;
        //base case
        if (this.subDirs.isEmpty()){
            res+=ident(level)+"Document: ";
            check = true;
            for (Document i : this.documents){
                files file = new files();
                file.setDoc(i);
                if(cri.search(file, crilist)){
                    res+=ident(level)+i.lis();
                    check = false;
                }
            }
            if (check)res+=ident(level)+"\tEmpty";
            res+=ident(level)+"Directory:"+ident(level)+"\tEmpty";
            return res;
        }


        res+=ident(level)+"Document: ";
        check = true;
        for (Document i : this.documents){
            files file = new files();
            file.setDoc(i);
            if(cri.search(file, crilist)){
                res+=ident(level)+i.lis();
                check = false;
            }
        }
        if (check)res+=ident(level)+"\tEmpty";

        res+=ident(level)+"Directory:";
        check = true;
        boolean check2 = true;
        for (Directory i : this.subDirs){
            if(i.checkCrilist(cri, crilist)){
                res+=i.rCri(cri, crilist, level+1);
                check2 = false;
            }
            else {
                files file = new files();
                file.setDir(i);
                if(cri.search(file, crilist)){
                    res+=ident(level)+i.lis();
                    check = false;
                }
            }
        }
        if(check&&check2)res+=ident(level)+"\tEmpty";

        return res;
    }

    public void savefold(Path path){
        //
        if(!this.documents.isEmpty()){
            for (Document i : this.documents){
                try {
                    Files.write(path.resolve(i.getname()+"."+i.gettype()), i.getcontent().getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);

                }catch (IOException e) {
                    System.err.println("Error writing document" + e.getMessage());
                }
            }}
        if(!this.subDirs.isEmpty()){
            for (Directory i : this.subDirs){
                try{
                    Files.createDirectory(path.resolve(i.getname()));
                    if (!i.documents.isEmpty() || !i.subDirs.isEmpty()){
                        i.savefold(path.resolve(i.getname()));
                    }}catch (IOException e) {
                    System.err.println("Error creating directory" + e.getMessage());
                }
            }}

    }

    public Document getdoc(String name){
        for(Document i : this.documents){
            if (i.getname().equals(name))return i;
        }
        return null;
    }

    public void loadfold(Path path) {

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(path)) {
            for (Path entry : stream) {

                if (Files.isDirectory(entry)) {

                    Directory subDirectory = new Directory(entry.getFileName().toString());
                    subDirectory.loadfold(entry);
                    this.createDirectory(subDirectory);
                }
                else if (Files.isRegularFile(entry)) {

                    String name = entry.getFileName().toString();
                    String content = new String(Files.readAllBytes(entry));
                    String type = name.substring(name.lastIndexOf('.') + 1);
                    Document document = new Document(name.substring(0, name.lastIndexOf(".")),type,content);
                    this.createDocument(document);
                }
            }

        } catch (IOException e) {
            System.err.println("Error loading directory: " + e.getMessage());
        }
    }
}
