package hk.edu.polyu.comp.comp2021.cvfs.model;

public class files{
    Directory directory;
    Document document;
    public void setDir(Directory d){
        this.directory = d;
    }
    public void setDoc(Document d){
        this.document = d;
    }

    public Document getDoc(){
        return this.document;
    }
    public Directory getDir(){
        return this.directory;
    }

}
