package hk.edu.polyu.comp.comp2021.cvfs.model;
public class Document {
    public String name;
    public String type;
    public String content;
    public int size;

    public Document (String name, String type, String content){
        this.name = name;

        
        this.type = type;
        this.content = content;
        size = 40 + content.length()*2;
    }

    public void rename(String name){
        this.name = name;
    }
    public int getsize(){
        return this.size;
    }
    public String getname(){
        return this.name;
    }
    public String gettype(){
        return this.type;
    }
    public String getcontent(){
        return this.content;
    }

    public String lis(){
        String r = "\tName: "+this.name+", Type: "+this.type+", Size: "+this.size+" bytes";
        return r;
    }
}
