package hk.edu.polyu.comp.comp2021.cvfs;

import hk.edu.polyu.comp.comp2021.cvfs.model.CVFS;
import java.util.Scanner;

public class Application {

    public static void main(String[] args){
        
        CVFS cvfs = new CVFS();
        // Initialize and utilize the system

        String command="";
        do{
            System.out.println("Enter a command ");
            Scanner objScanner = new Scanner(System.in);
            command = objScanner.nextLine().trim();
            cvfs.getcommand(command);

        }while(!command.equalsIgnoreCase("quit"));
    }
}
