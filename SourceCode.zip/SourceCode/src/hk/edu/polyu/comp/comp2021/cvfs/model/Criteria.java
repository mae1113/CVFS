package hk.edu.polyu.comp.comp2021.cvfs.model;
import java.util.ArrayList;

public class Criteria {
    public String criName;
    public String[] criterion;
    public Criteria(String criName, String[] criterion){
        this.criName = criName;
        this.criterion = criterion;
    }

    public String[] getcriterion(){
        return this.criterion;
    }
    public String getcriName(){
        return this.criName;
    }

    //REQ 10
    public boolean isDoc(files file){
        return file.directory==null;
    }

    public boolean search(files file, ArrayList<Criteria> crilist){
        //REQ 10
        if(this.getcriName().equals("IsDocument")){
            return this.isDoc(file);
        }

        String[] criterion = this.getcriterion();
        String cri = criterion[0];
        switch (cri) {
            case "name":
                if(isDoc(file))return file.getDoc().getname().contains(criterion[2]);
                else return file.getDir().getname().contains(criterion[2]);
            
            case "type":
                if (!isDoc(file))return false;
                return file.getDoc().gettype().equals(criterion[2]);

            case "size":
                int filesize;
                if(isDoc(file))filesize = file.getDoc().getsize();
                else filesize = file.getDir().getsize();
                switch (criterion[1]) {
                    case ">":
                        return filesize > Integer.valueOf(criterion[2]);
                    case "<":
                        return filesize < Integer.valueOf(criterion[2]);
                    case ">=":
                        return filesize >= Integer.valueOf(criterion[2]);
                    case "<=":
                        return filesize <= Integer.valueOf(criterion[2]);
                    case "==":
                        return filesize == Integer.valueOf(criterion[2]);
                    case "!=":
                        return filesize != Integer.valueOf(criterion[2]);
                }

            case "~":
                Criteria tempcri=crilist.get(1);
                for (Criteria i : crilist){
                    if(i.getcriName().equals(criterion[1])){
                        tempcri = i;
                    }
                }
                return !tempcri.search(file, crilist);

            default:
                Criteria c1 = crilist.get(1);
                Criteria c2 = crilist.get(1);
                boolean check1 = false;
                boolean check2 = false;
                for (Criteria i : crilist){
                    if(i.getcriName().equals(cri)){
                        c1 = i;
                        check1 = true;
                    }
                    if(i.getcriName().equals(criterion[2])){
                        c2 = i;
                        check2 = true;
                    }
                    if(check1&&check2)break;
                }
                if (criterion[1].equals("&&")) return c1.search(file, crilist)&&c2.search(file, crilist);
                else return c1.search(file, crilist)||c2.search(file, crilist);
        }
    }
}
