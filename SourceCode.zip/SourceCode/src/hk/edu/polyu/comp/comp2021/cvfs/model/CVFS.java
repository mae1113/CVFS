package hk.edu.polyu.comp.comp2021.cvfs.model;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;

public class CVFS {
    String root;
    ArrayList<String> dirlis = new ArrayList<String>();
    ArrayList<Disk> disks = new ArrayList<Disk>();
    ArrayList<Criteria> criterias = new ArrayList<Criteria>();
    Directory workDirectory;
    Disk curDisk;
    ArrayList<String[]> commandhis = new ArrayList<String[]>();
    ArrayList<String[]> undohis = new ArrayList<String[]>();
    boolean redocheck = false;
    boolean undocheck = false;

    public boolean wrongName(String name){
        if (name.isEmpty()||name.length()>10){
            System.out.println("File name may have at most 10 characters and not empty");
            return true;
        }
        if (!name.matches("[a-zA-Z0-9]+")){
            System.out.println("Only digits and English letters are allowed in file names");
            return true;
        }
        return false;
    }

    public void createDisk(int size){
        Disk d = new Disk(size);
        this.disks.add(d);
        this.root = d.getname();

        this.dirlis.clear();
        this.dirlis.add(root);
        this.workDirectory = this.disks.get(this.disks.size()-1).getDirectory();
        this.curDisk = this.disks.get(this.disks.size()-1);
    }

    //REQ 9, 11
    public boolean isCriNameValid(String name){
        if (!name.matches("[a-zA-Z]+")||name.length()!=2){
            System.out.println("Please enter a two English letters for criteria name!");
            return false;
        }
        return true;
    }

    //REQ 9 11 13 14
    public boolean isCriExist(String name){
        for (Criteria a: this.criterias){
            if(a.getcriName().equals(name))return true;
        }
        return false;
    }

    public void DelCri(String name){
        Criteria reqCriteria = criterias.get(1);
        for (Criteria i : criterias){
            if (i.getcriName().equals(name)){
                reqCriteria = i;break;
            }
        }
        criterias.remove(reqCriteria);
    }

    public CVFS(){
        //REQ10
        String[] a = {"Evaluates to true if and only if on a document."};
        Criteria isdoc = new Criteria("IsDocument", a) ;
        criterias.add(isdoc);
    }

    public void getcommand(String command){
        String[] com = command.split(" ");
        String realcom = com[0];

        //REQ 1
        if(realcom.equals("newDisk")){
            try {
                try {
                    if(Integer.valueOf(com[1])<0){
                        System.out.println("The disk size should not be negative!");
                        return;
                    }
                    this.createDisk(Integer.parseInt(com[1]));
                    System.out.println("Disk created!");
                }
                catch (NumberFormatException e) {
                    System.out.println("Invalid disk size. Please enter a valid integer.");
                }
                commandhis.clear();
                undohis.clear();

            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"newDisk [diskSize]\".");
            }

        }

        //REQ17
        else if (realcom.equalsIgnoreCase("quit")) {
            System.out.println("Exiting program...");
            System.exit(0);
        }
        else if (this.workDirectory==null) return;
        //REQ 2
        else if(realcom.equals("newDoc")){
            try {
                if(wrongName(com[1])){
                    return;
                }
                String resString="";
                for (int i =3;i<com.length;i++){
                    resString += com[i];
                }

                Document doc = new Document(com[1], com[2], resString);
                Disk curdisk = this.curDisk;
                if(curdisk.outofsize(Integer.valueOf(doc.getsize())))return;

                this.workDirectory.createDocument(doc);

                if(this.workDirectory.executedfully()){
                    curdisk.increaseSize(doc.getsize());

                    System.out.println("Document created!");
                    if(!undocheck)commandhis.add(com);
                    if(!redocheck && !undocheck)undohis.clear();
                    redocheck = false;
                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"newDoc [docName] [docType] [docContent]\".");
            }
        }

        //REQ 3
        else if(realcom.equals("newDir")){
            try {

                if(wrongName(com[1])) return;

                Directory d = new Directory(com[1]);
                Disk curdisk = this.curDisk;
                if(curdisk.outofsize(Integer.valueOf(d.getsize()))) return;

                this.workDirectory.createDirectory(d);
                if(this.workDirectory.executedfully()){
                    curdisk.increaseSize(d.getsize());

                    System.out.println("Directory created!");
                    if(!undocheck)commandhis.add(com);
                    if(!redocheck&&!undocheck)undohis.clear();
                    redocheck = false;

                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"newDir [dirName]\".");
            }
        }

        //REQ 4
        else if (realcom.equals("delete")){
            try {
                if (!this.workDirectory.exist(com[1])){
                    System.out.println("File not found!");
                    return;
                }

                //for undo
                files file = new files();
                for (Document i : this.workDirectory.documents){
                    if(i.getname().equals(com[1]))file.setDoc(i);
                }

                for (Directory i : this.workDirectory.subDirs){
                    if(i.getname().equals(com[1]))file.setDir(i);
                }
                String undoString;
                if (file.getDir()==null){
                    undoString = file.getDoc().getname()+" "+file.getDoc().gettype()+" "+file.getDoc().getcontent();
                }
                else {
                    undoString = file.getDir().getname();
                }


                int minus = this.workDirectory.deleteFile(com[1]);
                if(this.workDirectory.executedfully()){
                    System.out.println("File deleted!");
                    Disk curdisk = this.curDisk;
                    curdisk.decraseSize(minus);

                    com[1] = undoString;
                    if(!undocheck)commandhis.add(com);

                    if(!redocheck&&!undocheck)undohis.clear();
                    redocheck = false;

                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"delete [fileName]\".");
            }
        }

        //REQ 5
        else if(realcom.equals("rename")){
            try {
                if(wrongName(com[2]))return;
                if (!this.workDirectory.exist(com[1])){
                    System.out.println("File not found!");
                    return;
                }

                if(this.workDirectory.rename(com[1], com[2])){
                    System.out.println("File renamed!");
                    if(!undocheck)commandhis.add(com);
                    if(!redocheck&&!undocheck)undohis.clear();
                    redocheck = false;

                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"rename [oldFileName] [newFileName]\".");
            }
        }

        //REQ 6
        else if(realcom.equals("changeDir")){
            try {
                if (!com[1].equals("..")&&!this.workDirectory.existDir(com[1])){
                    System.out.println("Directory not found!");
                    return;
                }
                if (com[1].equals("..")){
                    if(this.workDirectory.getname().equals(this.dirlis.get(0))){
                        System.out.println("This is already the root directory!");
                        return;
                    }
                    this.dirlis.remove(this.dirlis.size()-1);
                    //switch directions for undo
                    com[1] = this.workDirectory.getname();
                    this.workDirectory = this.curDisk.getDirectory();
                    for (int i=1; i< this.dirlis.size(); i++){
                        this.workDirectory = this.workDirectory.getDirectory(this.dirlis.get(i));
                    }
                    System.out.println("Working directory changed!");

                    if(!undocheck)commandhis.add(com);
                    if(!redocheck&&!undocheck)undohis.clear();
                    redocheck = false;

                }

                else{
                    this.workDirectory = this.workDirectory.getDirectory(com[1]);
                    this.dirlis.add(com[1]);
                    System.out.println("Working directory changed!");

                    //changed direction
                    com[1] = "..";
                    if(!undocheck)commandhis.add(com);
                    if(!redocheck&&!undocheck)undohis.clear();
                    redocheck = false;

                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"changeDir [dirName]\".");
            }
        }

        //REQ 7
        else if (realcom.equals("list")){
            this.workDirectory.list();
        }

        //REQ 8
        else if (realcom.equals("rList")){
            System.out.println(this.workDirectory.rList(0));
            System.out.println("Total number: "+this.workDirectory.totalcount()+", total size: "+this.workDirectory.totalsize()+"\n");
        }

        //REQ 9 
        else if (realcom.equals("newSimpleCri")){
            try {
                if (!isCriNameValid(com[1]))return;
                if (isCriExist(com[1])){
                    System.out.println("Criteria name already exists!");
                    return;
                }
                String[] criterion = new String[3];
                boolean check=false;
                switch(com[2]){
                    case "name" :
                        if (!com[3].equals("contains")){
                            System.out.println("If attribute is name, operator can only be \"contains\"");
                            return;
                        }
                        if (!com[4].startsWith("\"")||!com[4].endsWith("\"")||com[4].length()<=2){
                            System.out.println("If attribute is name, val can only be a string in the double quote!");
                            return;
                        }
                        break;

                    case "type" :
                        if (!com[3].equals("equals")){
                            System.out.println("If attribute is type, operator can only be \"equals\"");
                            return;
                        }
                        if (!com[4].startsWith("\"")||!com[4].endsWith("\"")||com[4].length()<=2){
                            System.out.println("If attribute is type, val can only be a string in the double quote!");
                            return;
                        }
                        String valtemp = com[4].substring(1,com[4].length()-1);
                        String[] t = {"java","txt","html","css"};
                        for (int i=0; i<t.length; i++){
                            if (valtemp.equals(t[i])){
                                check=true;
                            }
                        }
                        if(!check){
                            System.out.println("If attribute is type, val can only be html, css, java, or txt!");
                            return;
                        }
                        break;

                    case "size" :
                        String[] s = {">","<",">=","<=","==","!="};
                        for (int i=0; i<s.length; i++){
                            if (com[3].equals(s[i])){
                                check=true;
                            }
                        }
                        if(!check){
                            System.out.println("If attribute is size, operator can only be >, <, >=, <=, ==, or !=");
                            return;
                        }
                        if (!com[4].matches("[0-9]+")){
                            System.out.println("If attribute is size, val must be integer");
                            return;
                        }
                        break;

                    default :
                        System.out.println("Attribute name can only be \"name\", \"type\", and \"size\"");
                        return;
                }
                for (int i=0 ;i<3;i++){
                    if (com[i+2].startsWith("\"")&&com[i+2].endsWith("\"")){
                        String res = com[i+2].substring(1,com[i+2].length()-1);
                        criterion[i] = res;
                    }
                    else{
                        criterion[i] = com[i+2];
                    }
                }
                Criteria cri = new Criteria(com[1], criterion);
                criterias.add(cri);
                System.out.println("New criteria created!\n");
                if(!undocheck)commandhis.add(com);
                if(!redocheck&&!undocheck)undohis.clear();
                redocheck = false;
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"newSimpleCri [criName] [attrName] [op] [val]\".");
            }
        }

        //REQ 10 in CVFS class initialize

        //REQ 11
        else if(realcom.equals("newNegation")){
            try {
                if (!isCriNameValid(com[1]))return;
                if (isCriExist(com[1])){
                    System.out.println("Criteria name already exists!");
                    return;
                }
                if (!isCriExist(com[2])){
                    System.out.println("Criteria not found!");
                    return;
                }

                String[] criterion = {"~", com[2]};
                Criteria cri = new Criteria(com[1], criterion);
                criterias.add(cri);
                System.out.println("New criteria created!\n");
                if(!undocheck)commandhis.add(com);
                if(!redocheck&&!undocheck)undohis.clear();
                redocheck = false;
            }

            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"newNegation [criName1] [criName2]\".");
            }
        }

        else if(realcom.equals("newBinaryCri")){
            try {
                if (!isCriNameValid(com[1]))return;
                if (isCriExist(com[1])){
                    System.out.println("Criteria name already exists!");
                    return;
                }
                if (!isCriExist(com[2])||!isCriExist(com[4])){
                    System.out.println("Criteria not found!");
                    return;
                }
                if (!com[3].equals("&&")&&!com[3].equals("||")){
                    System.out.println("Logic operator can only be && or || !");
                    return;
                }
                if(com[2].equals(com[4])){
                    System.out.println("The two selected criteria can not be the same");
                    return;
                }

                String[] criterion = {com[2], com[3], com[4]};
                Criteria cri = new Criteria(com[1], criterion);
                criterias.add(cri);
                System.out.println("New criteria created!\n");
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"newBinaryCri [criName1] [criName3] [criName4]\".");
            }
        }

        //REQ 12
        else if(realcom.equals("printAllCriteria")){
            String res="\nCriterias:\n\tCriName:\t|Criterion:";
            for (Criteria i : criterias){
                if(i.getcriName().equals("IsDocument")){
                    res+="\n\t"+i.getcriName()+"\t|";
                    res+=i.getcriterion()[0] +" ";
                    continue;
                }
                res+="\n\t"+i.getcriName()+"\t\t|";
                for(String j :i.getcriterion()){
                    res+=j +" ";
                }
            }
            System.out.println(res);
        }

        //REQ 13
        else if(realcom.equals("search")){
            try {
                if (!isCriExist(com[1])){
                    System.out.println("Criteria not found!");
                    return;
                }
                Criteria reqCriteria = criterias.get(1);
                for (Criteria i :criterias){
                    if (i.getcriName().equals(com[1])){
                        reqCriteria = i;break;
                    }
                }
                Directory tdir = this.workDirectory.CriList(reqCriteria, criterias);
                tdir.list();

                return;
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"search [criName]\".");
            }
        }

        //REQ 14
        else if(realcom.equals("rSearch")){
            try {
                if (!isCriExist(com[1])){
                    System.out.println("Criteria not found!");
                    return;
                }
                Criteria reqCriteria = criterias.get(1);
                for (Criteria i :criterias){
                    if (i.getcriName().equals(com[1])){
                        reqCriteria = i;break;
                    }
                }
                System.out.println(this.workDirectory.rCri(reqCriteria, criterias, 0));
                System.out.println("Total number: "+this.workDirectory.rcricount(reqCriteria, criterias, 0)+", total size: "+this.workDirectory.rcrisize(reqCriteria, criterias, 0)+"\n");

                return;
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"rSearch [criName]\".");
            }
        }

        //bonus 2 undo part
        else if(realcom.equals("undo")){
            try {if (commandhis.isEmpty()){
                System.out.println("Previous step cannot be undo.");
                return;
            }
                int last = commandhis.size()-1;
                String[] undocommand = commandhis.get(last);

                System.out.println("Undo successfully");
                String comName = undocommand[0];
                undocheck = true;
                switch (comName) {
                    case "newDoc":
                        String newdoc= "delete "+ undocommand[1];
                        undohis.add(undocommand);
                        commandhis.remove(last);
                        getcommand(newdoc);
                        break;

                    case "newDir":
                        String newdir= "delete "+ undocommand[1];
                        undohis.add(undocommand);
                        commandhis.remove(last);
                        getcommand(newdir);
                        break;

                    case "delete":
                        String[] nfile = undocommand[1].split(" ");
                        String newf = "";
                        if (nfile.length>1){
                            newf = "newDoc "+nfile[0]+" "+nfile[1]+" "+nfile[2];
                        }
                        else newf = "newDir "+nfile[0];
                        undohis.add(undocommand);
                        commandhis.remove(last);
                        getcommand(newf);
                        break;

                    case "rename":
                        String rename= "rename "+ undocommand[2]+" "+undocommand[1];
                        undohis.add(undocommand);
                        commandhis.remove(last);
                        getcommand(rename);
                        break;

                    case "changeDir":
                        if (undocommand[1].equals("..")){
                            String changedir= "changeDir "+ undocommand[1];
                            commandhis.remove(last);

                            undocommand[1] = this.workDirectory.getname();
                            undohis.add(undocommand);
                            getcommand(changedir);
                        }
                        else {
                            String changedir= "changeDir "+ undocommand[1];
                            commandhis.remove(last);

                            undocommand[1] = "..";
                            undohis.add(undocommand);
                            getcommand(changedir);
                        }
                        break;

                    case "newSimpleCri":
                        undohis.add(undocommand);
                        commandhis.remove(last);
                        DelCri(undocommand[1]);
                        break;

                    case "newNegation":
                        undohis.add(undocommand);
                        commandhis.remove(last);
                        DelCri(undocommand[1]);
                        break;
                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"undo [newDoc/ newDir/ delete/" +
                        " rename/ changeDir/ newSimpleCri/ newNegation]\".");
            }
        }

        // bonus 2 redo part
        else if (realcom.equals("redo")){
            try {
                if (undohis.isEmpty()){
                    System.out.println("Cannot redo without undo.");
                    return;
                }
                int last = undohis.size()-1;
                String[] redocommand = undohis.get(last);

                System.out.println("redo successfully");
                String comName = redocommand[0];
                redocheck = true;
                switch (comName) {
                    case "newDoc":
                        String newdoc= "newDoc " + redocommand[1] + " " + redocommand[2] + " " + redocommand[3];
                        undohis.remove(last);
                        getcommand(newdoc);
                        break;

                    case "newDir":
                        String newdir= "newDir "+ redocommand[1];
                        undohis.remove(last);
                        getcommand(newdir);
                        break;

                    case "delete":
                        String delete= "delete "+ redocommand[1];
                        undohis.remove(last);
                        getcommand(delete);
                        break;

                    case "rename":
                        String rename= "rename "+ redocommand[1]+" "+redocommand[2];
                        undohis.remove(last);
                        getcommand(rename);
                        break;

                    case "changeDir":
                        String changedir= "changeDir "+ redocommand[1];
                        undohis.remove(last);
                        getcommand(changedir);
                        break;

                    case "newSimpleCri":
                        String newSimpleCri = "newSimpleCri "+redocommand[1]+" "+redocommand[2]+" "+redocommand[3]+" "+redocommand[4];
                        undohis.remove(last);
                        getcommand(newSimpleCri);
                        break;

                    case "newNegation":
                        String newNegation = "newNegation "+redocommand[1]+" "+redocommand[2];
                        undohis.remove(last);
                        getcommand(newNegation);
                        break;
                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: please enter \"redo [newDoc/ newDir/ delete/" +
                        " rename/ changeDir/ newSimpleCri/ newNegation]\".");
            }
        }

        //REQ 15 save
        else if (realcom.equals("save")){
            try {
                Path path = Paths.get(com[1]);
                this.workDirectory.savefold(path);
                if(criterias.size()>1){ //bonus 1
                    String res ="";
                    boolean check=false;
                    for (int i = 1; i < criterias.size(); i++) {
                        switch (criterias.get(i).getcriterion()[0]) {
                            case "size":
                                res+= "newSimpleCri ";
                                break;
                            case "type":
                                res+= "newSimpleCri ";
                                break;
                            case "name":
                                res+= "newSimpleCri ";
                                break;
                            default:
                                if(criterias.get(i).getcriterion().length==3){
                                    res+="newBinaryCri ";
                                }else res+="newNegation ";
                        }
                        res +=criterias.get(i).getcriName()+" ";
                        for (String j : criterias.get(i).getcriterion()){
                            if(check){
                                res+="\""+j+"\"";
                                check=false;
                                continue;
                            }
                            if(j.equals("~"))continue;
                            res+=j+" ";
                            if(j.equals("equals")||j.equals("contains"))check=true;
                            else check= false;
                        }
                        res+="\n";
                    }
                    try {
                        Files.write(path.resolve("Criteria_List.txt"), res.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                    }catch (IOException e) {}
                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error : please enter \"save [path]\".");
            }
        }

        //REQ16
        else if (realcom.equals("load")){
            try {
                Path path = Paths.get(com[1]);
                this.workDirectory.loadfold(path);
                if(this.workDirectory.exist("Criteria_List")){
                    String[] crilist = this.workDirectory.getdoc("Criteria_List").getcontent().split("\n");
                    for(String i : crilist)this.getcommand(i);
                    this.getcommand("delete Criteria_List");
                }
            }
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error : please enter \"load [path]\".");
            }
        }

        undocheck =false;
        redocheck = false;
    }
}
